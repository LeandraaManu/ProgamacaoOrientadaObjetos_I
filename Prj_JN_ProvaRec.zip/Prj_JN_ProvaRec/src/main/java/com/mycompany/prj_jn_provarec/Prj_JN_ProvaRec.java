/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prj_jn_provarec;

import com.mycompany.prj_jn_provarec.menu.menu;

/**
 *
 * @author janai
 */
public class Prj_JN_ProvaRec {

    public static void main(String[] args) {
        menu.mostrarMenu();
    }
}
