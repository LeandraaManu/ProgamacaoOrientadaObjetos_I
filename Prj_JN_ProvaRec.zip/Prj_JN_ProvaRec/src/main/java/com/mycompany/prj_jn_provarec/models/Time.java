/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.models;

import java.util.List;
import java.util.UUID;

/**
 *
 * @author janai
 */
public class Time 
{
    private String nome;
    private String identificador;
    private List<Jogador> lstJogador;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public List<Jogador> getLstJogador() {
        return lstJogador;
    }

    public void setLstJogador(List<Jogador> lstJogador) {
        this.lstJogador = lstJogador;
    }
    
    
    
}
