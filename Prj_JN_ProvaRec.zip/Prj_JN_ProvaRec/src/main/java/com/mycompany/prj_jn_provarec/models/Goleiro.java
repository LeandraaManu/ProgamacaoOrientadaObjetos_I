/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.models;

/**
 *
 * @author janai
 */
public class Goleiro extends Jogador
{
    private int nroDefesas;

    public int getNroDefesas() {
        return nroDefesas;
    }

    public void setNroDefesas(int nroDefesas) {
        this.nroDefesas = nroDefesas;
    }
    
    
    
}
