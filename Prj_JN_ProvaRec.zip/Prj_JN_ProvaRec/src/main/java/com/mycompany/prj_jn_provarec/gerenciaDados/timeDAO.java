/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.gerenciaDados;

import com.mycompany.prj_jn_provarec.models.Atacante;
import com.mycompany.prj_jn_provarec.models.Goleiro;
import com.mycompany.prj_jn_provarec.models.Jogador;
import com.mycompany.prj_jn_provarec.models.Time;
import com.mycompany.prj_jn_provarec.util.EscreverArquivo;
import com.mycompany.prj_jn_provarec.util.LerArquivo;
import java.io.BufferedReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author janai
 */
public class timeDAO 
{
    private final String ARQUIVO = "c:\\EmpresaPessoa.txt";
    private final boolean MANTER = true;
    
     public void salvarTime (Time t)
    {
        String dados = "" + t.getNome() + ", " + t.getIdentificador();
        List<Jogador> lstJogador = t.getLstJogador();
        for (Jogador jogador : lstJogador)
        {
            if (jogador instanceof Goleiro g) {
                dados += ";" + g.getNome() + ", " + g.getDataNasc() + ", " + g.getNroDefesas();
            } else if (jogador instanceof Atacante a) {
                dados += ";" + a.getNome() + ", " + a.getDataNasc() + ", " + a.getNroGols();
            }
           
        }
        new EscreverArquivo().escrever(ARQUIVO, dados, MANTER);
    }
    
     public Time buscarTime (String identificador)
    {
        BufferedReader br = new LerArquivo().ler(ARQUIVO);
        if(br == null)
        {
            return null;
        }
        Map<String,Time> map = new HashMap<>();
        
        try{
            while (br.ready()){
                String itensString[] = br.readLine().split(";");
                
                if(itensString.length != 0)
                {
                    Time t = new Time();
                    
                    String objTime[] = itensString[0].split(",");
                    t.setNome(objTime[0].trim());
                    t.setIdentificador(objTime[1].trim());
                    
                    map.put(t.getIdentificador(), t); 
                    
                    if(itensString.length != 1)
                    {
                        List<Jogador> lstJogador = new LinkedList<>();
                        itensString = Arrays.copyOfRange(itensString, 1, itensString.length);
                        for (String item : itensString) 
                        {
                            String objJogador[] = item.split(",");
                            Jogador j;
                            if(item.contains("goleiro"))
                            {
                                Goleiro g = new Goleiro();
                                g.setNome(objJogador[0].trim());
                                g.setDataNasc(objJogador[1].trim());
                                g.setNroDefesas(Integer.parseInt(objJogador[2].trim()));
                                j = g;                                
                            }
                            else
                            {
                                Atacante a = new Atacante();
                                 a.setNome(objTime[0].trim());
                                 a.setDataNasc(objTime[1].trim());
                                 a.setNroGols(Integer.parseInt(objTime[2].trim()));
                                 j = a; 
                            }
                            lstJogador.add(j);
                        }
                        t.setLstJogador(lstJogador);

                    }
                }
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return map.get(identificador);
    }
}
