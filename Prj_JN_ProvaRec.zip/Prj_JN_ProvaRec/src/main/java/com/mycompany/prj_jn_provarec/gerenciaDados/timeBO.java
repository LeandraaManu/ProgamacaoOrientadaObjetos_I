/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.gerenciaDados;

import com.mycompany.prj_jn_provarec.models.Atacante;
import com.mycompany.prj_jn_provarec.models.Goleiro;
import com.mycompany.prj_jn_provarec.models.Jogador;
import com.mycompany.prj_jn_provarec.models.Time;
/**
 *
 * @author janai
 */
public class timeBO 
{
    timeDAO tDAO;
    
    public timeBO()
    {
        tDAO = new timeDAO();
    }
    
    public void salvarTime(Time t)
    {
        if(t.getIdentificador().trim().length() == 10)
        {
            tDAO.salvarTime(t);
        }else{
            System.err.println("Identificador incorreto!");
        }
    }
    
    public Time buscarTime(String identificador)
    {
        return tDAO.buscarTime(identificador);
    }
    
    public void mostrarDados(Time t)
    {
        if(t == null){
            System.out.println("Nenhum time cadastrado.");
            return;
        }
        printDadosTime(t);
        System.out.println
        ("****************************************");

        if(!t.getLstJogador().isEmpty())
        {   
            for(Jogador j : t.getLstJogador()){
            printDadosJogador(j);
            System.out.println("-----------------");
            }
        }
    }
    
    private void printDadosTime(Time t)
    {
        System.out.println("Nome: " + t.getNome());
        System.out.println("Identificador: " + t.getIdentificador()); 
    }
    
    private void printDadosJogador(Jogador jogador) {
        System.out.println("  Nome: " + jogador.getNome());
        System.out.println("  Data de Nascimento: " + jogador.getDataNasc());
        
        
        if (jogador instanceof Goleiro) {
            Goleiro goleiro = (Goleiro) jogador;
            System.out.println("  Numero de defesas " + goleiro.getNroDefesas());
        } else if (jogador instanceof Atacante) {
            Atacante atacante = (Atacante) jogador;
            System.out.println("  Numero de gols: " + atacante.getNroGols());
        }
    }
    
}
