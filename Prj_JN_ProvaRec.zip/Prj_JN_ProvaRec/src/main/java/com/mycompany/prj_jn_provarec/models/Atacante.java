/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.models;

/**
 *
 * @author janai
 */
public class Atacante extends Jogador
{
    private int nroGols;

    public int getNroGols() {
        return nroGols;
    }

    public void setNroGols(int nroGols) {
        this.nroGols = nroGols;
    }
    
    
}
