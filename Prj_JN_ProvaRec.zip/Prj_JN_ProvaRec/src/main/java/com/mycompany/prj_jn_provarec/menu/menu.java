/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.menu;

import com.mycompany.prj_jn_provarec.gerenciaDados.timeBO;
import com.mycompany.prj_jn_provarec.models.Atacante;
import com.mycompany.prj_jn_provarec.models.Goleiro;
import com.mycompany.prj_jn_provarec.models.Jogador;
import com.mycompany.prj_jn_provarec.models.Time;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author janai
 */
public class menu 
{
     private static Scanner scanner = new Scanner(System.in);
    private static timeBO timeBO = new timeBO();
    
    public static void mostrarMenu()
    {
        int opcao;
        do{
            System.out.println("\n--- Menu dos Times ---");
            System.out.println("1- Salvar Time");
            System.out.println("2- Consultar por Identificador");
            System.out.println("3- Sair");
            System.out.println("Escolha uma opcao: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao){
                case 1 -> salvarTime();
                case 2 -> {
                    System.out.println("Digite o Identificador:");
                    String identificador = scanner.nextLine();
                    listarTime(identificador);
                }
                case 3 -> System.out.print("Saindo do programa...");
                default -> System.out.print("Opcao invalida. Tente novamente.");
            }
        }while(opcao != 4);
        
        scanner.close();
    }
    
    private static void salvarTime()
    {
        System.out.println("\n--- Cadastro do Time ---");
        Time time = new Time();
        
        System.out.println("Nome do Time: ");
        time.setNome(scanner.nextLine());
        System.out.println("Identificador: ");
        time.setIdentificador(scanner.nextLine());
        
        String resposta;
        List<Jogador> jogador = new LinkedList<>();
        
        do{
            System.out.println("Deseja adicionar um novo jogador? (s/n): ");
            resposta = scanner.nextLine().toLowerCase();
            if(resposta.equals("s")){
                jogador.add(lerDadosJogador());
            }
        }while (resposta.equals("s"));
            
            time.setLstJogador(jogador);
            timeBO.salvarTime(time);
    }
    
    private static Jogador lerDadosJogador()
    {
        System.out.println("\n--- Cadastro do Jogador ---");
        System.out.println("Nome: ");
        String nome = scanner.nextLine();
        System.out.println("Data Nascimento: ");
        String data = scanner.nextLine();
        System.out.println("Tipo do jogador Goleiro / Atacante: ");
        String tipo = scanner.nextLine().toLowerCase();

        if (tipo.equals("goleiro")) {
            System.out.println("Numero de defesas: ");
            int defesa = scanner.nextInt();
            scanner.nextLine();
            Goleiro g = new Goleiro();
            g.setNome(nome);
            g.setDataNasc(data);
            g.setNroDefesas(defesa);
            return g;
        } else if(tipo.equals("atacante")) {
            System.out.println("Numero de Gols: ");
            int gols = scanner.nextInt();
            scanner.nextLine();
            Atacante a = new Atacante();
            a.setNome(nome);
            a.setDataNasc(data);
            a.setNroGols(gols);
            return a;
        }else{
         return null;
        }
    }
    
   private static void listarTime(String identificador){
        Time t = timeBO.buscarTime(identificador);
        if( t != null)
            timeBO.mostrarDados(t);
    }
}
