/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_jn_provarec.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author janai
 */
public class LerArquivo 
{
    public BufferedReader ler(String arquivo)
    {     
        BufferedReader br = null;
        try 
        {
            /*Define o caminho do arquivo que será 
            utilizado para leitura ou escrita*/
            File f = new File(arquivo);
            /*Cria um instancia do arquivo que será lido*/
            if(f.exists())
            {
            FileReader fr = new FileReader(f);
            /*Armazena o conteúdo do arquivo para
            leitura*/
            br = new BufferedReader(fr);
            //Lê todas as linhas que estão escritas no arquivo
            }
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }    
        return br;
    }
}
